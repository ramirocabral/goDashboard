"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Line, LineChart, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

export function SystemMetrics({ historicalData, realtimeData }) {
  // If no data is provided, use placeholder data
  const cpuData = historicalData?.cpuHistory || generatePlaceholderData("cpu")
  const memoryData = historicalData?.memoryHistory || generatePlaceholderData("memory")
  const diskData = historicalData?.diskHistory || generatePlaceholderData("disk")
  const networkData = historicalData?.networkHistory || generatePlaceholderData("network")

  return (
    <div className="grid gap-4">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          title="CPU Usage"
          value={`${realtimeData?.cpu?.usagePercent?.toFixed(2) || "0.00"}%`}
          description={`${realtimeData?.cpu?.cores || 0} cores @ ${realtimeData?.cpu?.mhz || 0} MHz`}
          progress={realtimeData?.cpu?.usagePercent || 0}
        />
        <MetricCard
          title="Memory Usage"
          value={`${realtimeData?.memory?.usagePercent?.toFixed(2) || "0.00"}%`}
          description={`${formatBytes(realtimeData?.memory?.used || 0)} / ${formatBytes(realtimeData?.memory?.total || 0)}`}
          progress={realtimeData?.memory?.usagePercent || 0}
        />
        <MetricCard
          title="Disk Usage"
          value={`${realtimeData?.disk?.usagePercent?.toFixed(2) || "0.00"}%`}
          description={`${formatBytes(realtimeData?.disk?.used || 0)} / ${formatBytes(realtimeData?.disk?.total || 0)}`}
          progress={realtimeData?.disk?.usagePercent || 0}
        />
        <MetricCard
          title="Network"
          value={`${formatBytes(realtimeData?.network?.rxSpeed || 0)}/s`}
          description={`↑ ${formatBytes(realtimeData?.network?.txSpeed || 0)}/s`}
          progress={0}
          showProgress={false}
        />
      </div>

      <Tabs defaultValue="cpu" className="space-y-4">
        <TabsList>
          <TabsTrigger value="cpu">CPU</TabsTrigger>
          <TabsTrigger value="memory">Memory</TabsTrigger>
          <TabsTrigger value="disk">Disk I/O</TabsTrigger>
          <TabsTrigger value="network">Network</TabsTrigger>
        </TabsList>
        <TabsContent value="cpu" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>CPU Usage History</CardTitle>
              <CardDescription>CPU utilization over time</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              <ChartContainer
                config={{
                  system: {
                    label: "System",
                    color: "hsl(var(--chart-1))",
                  },
                  user: {
                    label: "User",
                    color: "hsl(var(--chart-2))",
                  },
                  iowait: {
                    label: "I/O Wait",
                    color: "hsl(var(--chart-3))",
                  },
                }}
              >
                <AreaChart
                  data={cpuData}
                  margin={{
                    top: 10,
                    right: 30,
                    left: 0,
                    bottom: 0,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Area
                    type="monotone"
                    dataKey="system"
                    stackId="1"
                    stroke="var(--color-system)"
                    fill="var(--color-system)"
                  />
                  <Area
                    type="monotone"
                    dataKey="user"
                    stackId="1"
                    stroke="var(--color-user)"
                    fill="var(--color-user)"
                  />
                  <Area
                    type="monotone"
                    dataKey="iowait"
                    stackId="1"
                    stroke="var(--color-iowait)"
                    fill="var(--color-iowait)"
                  />
                </AreaChart>
              </ChartContainer>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="memory" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Memory Usage History</CardTitle>
              <CardDescription>Memory utilization over time</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              <ChartContainer
                config={{
                  used: {
                    label: "Used",
                    color: "hsl(var(--chart-1))",
                  },
                  cached: {
                    label: "Cached",
                    color: "hsl(var(--chart-2))",
                  },
                  buffers: {
                    label: "Buffers",
                    color: "hsl(var(--chart-3))",
                  },
                  free: {
                    label: "Free",
                    color: "hsl(var(--chart-4))",
                  },
                }}
              >
                <AreaChart
                  data={memoryData}
                  margin={{
                    top: 10,
                    right: 30,
                    left: 0,
                    bottom: 0,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Area
                    type="monotone"
                    dataKey="used"
                    stackId="1"
                    stroke="var(--color-used)"
                    fill="var(--color-used)"
                  />
                  <Area
                    type="monotone"
                    dataKey="cached"
                    stackId="1"
                    stroke="var(--color-cached)"
                    fill="var(--color-cached)"
                  />
                  <Area
                    type="monotone"
                    dataKey="buffers"
                    stackId="1"
                    stroke="var(--color-buffers)"
                    fill="var(--color-buffers)"
                  />
                  <Area
                    type="monotone"
                    dataKey="free"
                    stackId="1"
                    stroke="var(--color-free)"
                    fill="var(--color-free)"
                  />
                </AreaChart>
              </ChartContainer>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="disk" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Disk I/O History</CardTitle>
              <CardDescription>Disk read/write operations over time</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              <ChartContainer
                config={{
                  read: {
                    label: "Read",
                    color: "hsl(var(--chart-1))",
                  },
                  write: {
                    label: "Write",
                    color: "hsl(var(--chart-2))",
                  },
                }}
              >
                <LineChart
                  data={diskData}
                  margin={{
                    top: 10,
                    right: 30,
                    left: 0,
                    bottom: 0,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Line type="monotone" dataKey="read" stroke="var(--color-read)" />
                  <Line type="monotone" dataKey="write" stroke="var(--color-write)" />
                </LineChart>
              </ChartContainer>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="network" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Network Traffic History</CardTitle>
              <CardDescription>Network traffic over time</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              <ChartContainer
                config={{
                  rx: {
                    label: "Received",
                    color: "hsl(var(--chart-1))",
                  },
                  tx: {
                    label: "Transmitted",
                    color: "hsl(var(--chart-2))",
                  },
                }}
              >
                <BarChart
                  data={networkData}
                  margin={{
                    top: 10,
                    right: 30,
                    left: 0,
                    bottom: 0,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="rx" fill="var(--color-rx)" />
                  <Bar dataKey="tx" fill="var(--color-tx)" />
                </BarChart>
              </ChartContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function MetricCard({ title, value, description, progress, showProgress = true }) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground">{description}</p>
        {showProgress && (
          <div className="mt-4">
            <Progress value={progress} className="h-2" />
          </div>
        )}
      </CardContent>
    </Card>
  )
}

// Helper function to format bytes
function formatBytes(bytes, decimals = 2) {
  if (bytes === 0) return "0 Bytes"

  const k = 1024
  const dm = decimals < 0 ? 0 : decimals
  const sizes = ["Bytes", "KB", "MB", "GB", "TB", "PB"]

  const i = Math.floor(Math.log(bytes) / Math.log(k))

  return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i]
}

// Generate placeholder data for the charts
function generatePlaceholderData(type) {
  const times = Array.from({ length: 24 }, (_, i) => `${i}:00`)

  switch (type) {
    case "cpu":
      return times.map((time) => ({
        time,
        system: Math.floor(Math.random() * 30),
        user: Math.floor(Math.random() * 40),
        iowait: Math.floor(Math.random() * 10),
      }))
    case "memory":
      return times.map((time) => ({
        time,
        used: Math.floor(Math.random() * 4000),
        cached: Math.floor(Math.random() * 2000),
        buffers: Math.floor(Math.random() * 1000),
        free: Math.floor(Math.random() * 3000),
      }))
    case "disk":
      return times.map((time) => ({
        time,
        read: Math.floor(Math.random() * 100),
        write: Math.floor(Math.random() * 80),
      }))
    case "network":
      return times.map((time) => ({
        time,
        rx: Math.floor(Math.random() * 100),
        tx: Math.floor(Math.random() * 80),
      }))
    default:
      return []
  }
}

