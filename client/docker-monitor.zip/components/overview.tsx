"use client"

import { Line, LineChart, ResponsiveContainer, Tooltip } from "recharts"
import { ChartContainer, ChartTooltipContent } from "@/components/ui/chart"

export function Overview({ data }) {
  // If no data is provided, use placeholder data
  const chartData = data?.cpuHistory || generatePlaceholderData()

  return (
    <ChartContainer
      config={{
        cpu: {
          label: "CPU",
          color: "hsl(var(--chart-1))",
        },
        memory: {
          label: "Memory",
          color: "hsl(var(--chart-2))",
        },
        disk: {
          label: "Disk I/O",
          color: "hsl(var(--chart-3))",
        },
        network: {
          label: "Network",
          color: "hsl(var(--chart-4))",
        },
      }}
      className="h-[300px]"
    >
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={chartData}
          margin={{
            top: 5,
            right: 10,
            left: 10,
            bottom: 0,
          }}
        >
          <Tooltip content={<ChartTooltipContent />} />
          <Line
            type="monotone"
            dataKey="cpu"
            strokeWidth={2}
            activeDot={{
              r: 6,
              style: { fill: "var(--color-cpu)", opacity: 0.8 },
            }}
          />
          <Line
            type="monotone"
            dataKey="memory"
            strokeWidth={2}
            activeDot={{
              r: 6,
              style: { fill: "var(--color-memory)", opacity: 0.8 },
            }}
          />
          <Line
            type="monotone"
            dataKey="disk"
            strokeWidth={2}
            activeDot={{
              r: 6,
              style: { fill: "var(--color-disk)", opacity: 0.8 },
            }}
          />
          <Line
            type="monotone"
            dataKey="network"
            strokeWidth={2}
            activeDot={{
              r: 6,
              style: { fill: "var(--color-network)", opacity: 0.8 },
            }}
          />
        </LineChart>
      </ResponsiveContainer>
    </ChartContainer>
  )
}

// Generate placeholder data for the chart
function generatePlaceholderData() {
  return Array.from({ length: 24 }, (_, i) => ({
    name: `${i}:00`,
    cpu: Math.floor(Math.random() * 100),
    memory: Math.floor(Math.random() * 100),
    disk: Math.floor(Math.random() * 100),
    network: Math.floor(Math.random() * 100),
  }))
}

