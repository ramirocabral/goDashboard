"use client"

import { useState } from "react"
import { MoreHorizontal, Play, Square, RefreshCw, Trash2, Terminal } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"

export function ContainerList({ containers = [] }) {
  const [searchTerm, setSearchTerm] = useState("")

  // If no containers are provided, use placeholder data
  const containerData = containers.length > 0 ? containers : generatePlaceholderData()

  // Filter containers based on search term
  const filteredContainers = containerData.filter(
    (container) =>
      container.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      container.image.toLowerCase().includes(searchTerm.toLowerCase()) ||
      container.id.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Containers</CardTitle>
          <div className="flex items-center gap-2">
            <Input
              placeholder="Search containers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-[250px]"
            />
            <Button variant="outline" size="sm">
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[100px]">Status</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Image</TableHead>
              <TableHead>CPU</TableHead>
              <TableHead>Memory</TableHead>
              <TableHead>Created</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredContainers.map((container) => (
              <TableRow key={container.id}>
                <TableCell>
                  <StatusBadge status={container.status} />
                </TableCell>
                <TableCell className="font-medium">{container.name}</TableCell>
                <TableCell>{container.image}</TableCell>
                <TableCell>{container.cpu}%</TableCell>
                <TableCell>{container.memory} MB</TableCell>
                <TableCell>{container.created}</TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <span className="sr-only">Open menu</span>
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      {container.status === "running" ? (
                        <DropdownMenuItem>
                          <Square className="mr-2 h-4 w-4" />
                          Stop
                        </DropdownMenuItem>
                      ) : (
                        <DropdownMenuItem>
                          <Play className="mr-2 h-4 w-4" />
                          Start
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuItem>
                        <RefreshCw className="mr-2 h-4 w-4" />
                        Restart
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Terminal className="mr-2 h-4 w-4" />
                        Logs
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-red-600">
                        <Trash2 className="mr-2 h-4 w-4" />
                        Remove
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

function StatusBadge({ status }) {
  let variant = "default"

  switch (status) {
    case "running":
      variant = "success"
      break
    case "stopped":
      variant = "secondary"
      break
    case "paused":
      variant = "warning"
      break
    case "error":
      variant = "destructive"
      break
    default:
      variant = "outline"
  }

  return <Badge variant={variant}>{status}</Badge>
}

// Generate placeholder data for the container list
function generatePlaceholderData() {
  const statuses = ["running", "stopped", "paused", "error"]
  const images = ["nginx:latest", "postgres:13", "redis:alpine", "mongodb:4.4", "node:14"]
  const names = ["web-server", "db-primary", "cache", "auth-service", "api-gateway"]

  return Array.from({ length: 10 }, (_, i) => ({
    id: `container${i}`,
    name: `${names[Math.floor(Math.random() * names.length)]}-${i}`,
    image: images[Math.floor(Math.random() * images.length)],
    status: statuses[Math.floor(Math.random() * statuses.length)],
    cpu: (Math.random() * 10).toFixed(2),
    memory: Math.floor(Math.random() * 500),
    created: `${Math.floor(Math.random() * 30) + 1} days ago`,
  }))
}

