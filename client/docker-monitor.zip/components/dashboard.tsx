"use client"

import { useEffect, useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Overview } from "@/components/overview"
import { RecentActivity } from "@/components/recent-activity"
import { ContainerList } from "@/components/container-list"
import { SystemMetrics } from "@/components/system-metrics"
import { useWebSocket } from "@/hooks/use-websocket"
import { Loader2 } from "lucide-react"

export default function Dashboard() {
  const [staticData, setStaticData] = useState(null)
  const [historicalData, setHistoricalData] = useState(null)
  const [loading, setLoading] = useState(true)

  // WebSocket connection for real-time data
  const { data: realtimeData, connected } = useWebSocket("ws://localhost:8080/ws/metrics")

  // Fetch static data
  useEffect(() => {
    const fetchStaticData = async () => {
      try {
        const response = await fetch("http://localhost:8080/api/containers")
        const data = await response.json()
        setStaticData(data)
      } catch (error) {
        console.error("Error fetching static data:", error)
      }
    }

    const fetchHistoricalData = async () => {
      try {
        const response = await fetch("http://localhost:8080/api/metrics/history")
        const data = await response.json()
        setHistoricalData(data)
        setLoading(false)
      } catch (error) {
        console.error("Error fetching historical data:", error)
        setLoading(false)
      }
    }

    fetchStaticData()
    fetchHistoricalData()
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2 text-lg">Loading dashboard data...</span>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
      <div className="border-b">
        <div className="flex h-16 items-center px-4">
          <div className="ml-auto flex items-center space-x-4">
            <div className={`flex items-center space-x-2 ${connected ? "text-green-500" : "text-red-500"}`}>
              <div className={`h-2 w-2 rounded-full ${connected ? "bg-green-500 animate-pulse" : "bg-red-500"}`} />
              <span className="text-sm font-medium">{connected ? "Connected" : "Disconnected"}</span>
            </div>
          </div>
        </div>
      </div>
      <div className="flex-1 space-y-4 p-8 pt-6">
        <div className="flex items-center justify-between space-y-2">
          <h2 className="text-3xl font-bold tracking-tight">Docker Monitor Dashboard</h2>
        </div>
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="containers">Containers</TabsTrigger>
            <TabsTrigger value="metrics">System Metrics</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
          </TabsList>
          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Containers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{staticData?.containers?.length || 0}</div>
                  <p className="text-xs text-muted-foreground">{staticData?.runningContainers || 0} running</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">CPU Usage</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{realtimeData?.cpu?.usagePercent?.toFixed(2) || "0.00"}%</div>
                  <p className="text-xs text-muted-foreground">{realtimeData?.cpu?.cores || 0} cores</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Memory Usage</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{realtimeData?.memory?.usagePercent?.toFixed(2) || "0.00"}%</div>
                  <p className="text-xs text-muted-foreground">
                    {formatBytes(realtimeData?.memory?.used || 0)} / {formatBytes(realtimeData?.memory?.total || 0)}
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Disk Usage</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{realtimeData?.disk?.usagePercent?.toFixed(2) || "0.00"}%</div>
                  <p className="text-xs text-muted-foreground">
                    {formatBytes(realtimeData?.disk?.used || 0)} / {formatBytes(realtimeData?.disk?.total || 0)}
                  </p>
                </CardContent>
              </Card>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
              <Card className="col-span-4">
                <CardHeader>
                  <CardTitle>Resource Usage</CardTitle>
                </CardHeader>
                <CardContent className="pl-2">
                  <Overview data={historicalData} />
                </CardContent>
              </Card>
              <Card className="col-span-3">
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Container events in the last 24 hours</CardDescription>
                </CardHeader>
                <CardContent>
                  <RecentActivity data={staticData?.recentEvents || []} />
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          <TabsContent value="containers" className="space-y-4">
            <ContainerList containers={staticData?.containers || []} />
          </TabsContent>
          <TabsContent value="metrics" className="space-y-4">
            <SystemMetrics historicalData={historicalData} realtimeData={realtimeData} />
          </TabsContent>
          <TabsContent value="activity" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Activity Log</CardTitle>
                <CardDescription>Complete history of container events</CardDescription>
              </CardHeader>
              <CardContent>
                <RecentActivity data={staticData?.allEvents || []} showAll={true} />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

// Helper function to format bytes
function formatBytes(bytes, decimals = 2) {
  if (bytes === 0) return "0 Bytes"

  const k = 1024
  const dm = decimals < 0 ? 0 : decimals
  const sizes = ["Bytes", "KB", "MB", "GB", "TB", "PB"]

  const i = Math.floor(Math.log(bytes) / Math.log(k))

  return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i]
}

