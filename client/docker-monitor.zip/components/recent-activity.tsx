import { Activity, AlertTriangle, Check, Clock, RefreshCw, X } from "lucide-react"
import { cn } from "@/lib/utils"

export function RecentActivity({ data = [], showAll = false }) {
  // If no data is provided, use placeholder data
  const activityData = data.length > 0 ? data : generatePlaceholderData()

  // Limit the number of items unless showAll is true
  const displayData = showAll ? activityData : activityData.slice(0, 5)

  return (
    <div className="space-y-8">
      {displayData.map((item, index) => (
        <div className="flex items-start" key={index}>
          <div className={cn("flex h-9 w-9 items-center justify-center rounded-full", getStatusColor(item.status))}>
            {getStatusIcon(item.status)}
          </div>
          <div className="ml-4 space-y-1">
            <p className="text-sm font-medium leading-none">{item.container}</p>
            <p className="text-sm text-muted-foreground">{item.message}</p>
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {item.timestamp}
            </p>
          </div>
        </div>
      ))}
    </div>
  )
}

function getStatusColor(status) {
  switch (status) {
    case "started":
      return "bg-green-500/20 text-green-500"
    case "stopped":
      return "bg-orange-500/20 text-orange-500"
    case "error":
      return "bg-red-500/20 text-red-500"
    case "restarted":
      return "bg-blue-500/20 text-blue-500"
    default:
      return "bg-gray-500/20 text-gray-500"
  }
}

function getStatusIcon(status) {
  switch (status) {
    case "started":
      return <Check className="h-5 w-5" />
    case "stopped":
      return <X className="h-5 w-5" />
    case "error":
      return <AlertTriangle className="h-5 w-5" />
    case "restarted":
      return <RefreshCw className="h-5 w-5" />
    default:
      return <Activity className="h-5 w-5" />
  }
}

// Generate placeholder data for the activity feed
function generatePlaceholderData() {
  const containers = ["nginx", "postgres", "redis", "mongodb", "app-service"]
  const statuses = ["started", "stopped", "error", "restarted"]
  const messages = [
    "Container started successfully",
    "Container stopped",
    "Error: Out of memory",
    "Container restarted due to health check failure",
    "Image pulled successfully",
  ]

  return Array.from({ length: 10 }, (_, i) => ({
    container: containers[Math.floor(Math.random() * containers.length)],
    status: statuses[Math.floor(Math.random() * statuses.length)],
    message: messages[Math.floor(Math.random() * messages.length)],
    timestamp: `${Math.floor(Math.random() * 24)}h ${Math.floor(Math.random() * 60)}m ago`,
  }))
}

