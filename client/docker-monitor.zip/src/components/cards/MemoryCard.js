"use client"

import { useState, useEffect } from "react"
import { useWebSocket } from "../../contexts/WebSocketContext"
import { AreaChart, Area, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"
import TimeRangeSelector from "../TimeRangeSelector"
import { format, subSeconds } from "date-fns"

const MemoryCard = () => {
  const { memoryData, fetchHistoricalData } = useWebSocket()
  const [historicalData, setHistoricalData] = useState([])
  const [realtimeData, setRealtimeData] = useState([])
  const [selectedRange, setSelectedRange] = useState(3600) // 1 hour by default
  const [showHistorical, setShowHistorical] = useState(false)

  // Format bytes to human-readable format
  const formatBytes = (bytes, decimals = 2) => {
    if (!bytes) return "0 B"

    const k = 1024
    const dm = decimals < 0 ? 0 : decimals
    const sizes = ["B", "KB", "MB", "GB", "TB"]

    const i = Math.floor(Math.log(bytes) / Math.log(k))

    return `${Number.parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`
  }

  // Update realtime data when new memory data arrives
  useEffect(() => {
    if (memoryData) {
      setRealtimeData((prevData) => {
        const newData = [
          ...prevData,
          {
            time: new Date().getTime(),
            used: memoryData.used_percentage,
            total: memoryData.total,
            usedBytes: memoryData.used,
            freeBytes: memoryData.free,
          },
        ]

        // Keep only the last 30 data points (1 minute at 1 data point per 2 seconds)
        if (newData.length > 30) {
          return newData.slice(-30)
        }
        return newData
      })
    }
  }, [memoryData])

  // Fetch historical data when range changes
  useEffect(() => {
    if (showHistorical) {
      const fetchData = async () => {
        const endTime = new Date().toISOString()
        const startTime = subSeconds(new Date(), selectedRange).toISOString()
        const interval = Math.max(Math.floor(selectedRange / 60), 1) // At least 1 second interval

        const data = await fetchHistoricalData("memory", startTime, endTime, interval)
        if (data && data.stats) {
          setHistoricalData(
            data.stats.map((item) => ({
              time: new Date(item.timestamp).getTime(),
              used: item.used_percentage,
              total: item.total,
              usedBytes: item.used,
              freeBytes: item.free,
            })),
          )
        }
      }

      fetchData()
    }
  }, [selectedRange, showHistorical, fetchHistoricalData])

  // Format time for tooltip
  const formatTime = (time) => {
    return format(new Date(time), "HH:mm:ss")
  }

  // Custom tooltip
  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card p-2 border border-border rounded shadow-sm">
          <p className="text-sm">{`Time: ${formatTime(payload[0].payload.time)}`}</p>
          <p className="text-sm text-[hsl(var(--memory-color))]">{`Memory: ${payload[0].value.toFixed(2)}%`}</p>
          <p className="text-sm">{`Used: ${formatBytes(payload[0].payload.usedBytes)}`}</p>
          <p className="text-sm">{`Free: ${formatBytes(payload[0].payload.freeBytes)}`}</p>
        </div>
      )
    }
    return null
  }

  return (
    <div className="card">
      <div className="card-header">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-[hsl(var(--memory-color))] flex items-center justify-center mr-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 text-white"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <rect x="2" y="6" width="20" height="12" rx="2" ry="2"></rect>
                <path d="M22 6l-4-4H6L2 6"></path>
                <path d="M22 18l-4 4H6l-4-4"></path>
                <path d="M6 10h.01"></path>
                <path d="M10 10h.01"></path>
                <path d="M14 10h.01"></path>
                <path d="M18 10h.01"></path>
              </svg>
            </div>
            <div className="card-title">Memory</div>
          </div>
          <button className="text-sm text-primary hover:underline" onClick={() => setShowHistorical(!showHistorical)}>
            {showHistorical ? "Show Realtime" : "Show Historical"}
          </button>
        </div>
      </div>
      <div className="card-content">
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <div className="text-sm text-muted-foreground">Brand</div>
            <div className="font-medium">802C00000000</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">Size</div>
            <div className="font-medium">{formatBytes(memoryData?.total * 1024, 1)}</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">Type</div>
            <div className="font-medium">DDR4</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">Frequency</div>
            <div className="font-medium">3200 MHz</div>
          </div>
        </div>

        {showHistorical && (
          <div className="mb-4">
            <TimeRangeSelector selectedRange={selectedRange} onRangeChange={setSelectedRange} />
          </div>
        )}

        <div className="graph-container">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={showHistorical ? historicalData : realtimeData}
              margin={{ top: 5, right: 5, left: 0, bottom: 5 }}
            >
              <XAxis dataKey="time" type="number" domain={["dataMin", "dataMax"]} tickFormatter={formatTime} hide />
              <YAxis domain={[0, 100]} hide />
              <Tooltip content={<CustomTooltip />} />
              <Area
                type="monotone"
                dataKey="used"
                stroke="hsl(var(--memory-color))"
                fill="hsl(var(--memory-color))"
                fillOpacity={0.3}
                isAnimationActive={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="mt-2 flex justify-between items-center">
          <div className="stat-value">{memoryData?.used_percentage?.toFixed(2) || "0.00"}%</div>
          <div className="stat-label">
            {formatBytes(memoryData?.used * 1024)} / {formatBytes(memoryData?.total * 1024)}
          </div>
        </div>
      </div>
    </div>
  )
}

export default MemoryCard

