"use client"

import { useState, useEffect } from "react"
import { useWebSocket } from "../../contexts/WebSocketContext"
import { LineChart, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"
import TimeRangeSelector from "../TimeRangeSelector"
import { format, subSeconds } from "date-fns"

const CpuCard = ({ showAllCores }) => {
  const { cpuData, fetchHistoricalData } = useWebSocket()
  const [historicalData, setHistoricalData] = useState([])
  const [realtimeData, setRealtimeData] = useState([])
  const [selectedRange, setSelectedRange] = useState(3600) // 1 hour by default
  const [showHistorical, setShowHistorical] = useState(false)

  // Update realtime data when new CPU data arrives
  useEffect(() => {
    if (cpuData) {
      setRealtimeData((prevData) => {
        const newData = [
          ...prevData,
          {
            time: new Date().getTime(),
            usage: cpuData.usage.usage_percentage,
          },
        ]

        // Keep only the last 60 data points (1 minute at 1 data point per second)
        if (newData.length > 60) {
          return newData.slice(-60)
        }
        return newData
      })
    }
  }, [cpuData])

  // Fetch historical data when range changes
  useEffect(() => {
    if (showHistorical) {
      const fetchData = async () => {
        const endTime = new Date().toISOString()
        const startTime = subSeconds(new Date(), selectedRange).toISOString()
        const interval = Math.max(Math.floor(selectedRange / 60), 1) // At least 1 second interval

        const data = await fetchHistoricalData("cpu", startTime, endTime, interval)
        if (data && data.data) {
          setHistoricalData(
            data.data.map((item) => ({
              time: new Date(item.timestamp).getTime(),
              usage: item.usage_percentage,
            })),
          )
        }
      }

      fetchData()
    }
  }, [selectedRange, showHistorical, fetchHistoricalData])

  // Format time for tooltip
  const formatTime = (time) => {
    return format(new Date(time), "HH:mm:ss")
  }

  // Custom tooltip
  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card p-2 border border-border rounded shadow-sm">
          <p className="text-sm">{`Time: ${formatTime(payload[0].payload.time)}`}</p>
          <p className="text-sm text-[hsl(var(--cpu-color))]">{`CPU: ${payload[0].value.toFixed(2)}%`}</p>
        </div>
      )
    }
    return null
  }

  return (
    <div className="card">
      <div className="card-header">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-[hsl(var(--cpu-color))] flex items-center justify-center mr-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 text-white"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect>
                <rect x="9" y="9" width="6" height="6"></rect>
                <line x1="9" y1="1" x2="9" y2="4"></line>
                <line x1="15" y1="1" x2="15" y2="4"></line>
                <line x1="9" y1="20" x2="9" y2="23"></line>
                <line x1="15" y1="20" x2="15" y2="23"></line>
                <line x1="20" y1="9" x2="23" y2="9"></line>
                <line x1="20" y1="14" x2="23" y2="14"></line>
                <line x1="1" y1="9" x2="4" y2="9"></line>
                <line x1="1" y1="14" x2="4" y2="14"></line>
              </svg>
            </div>
            <div className="card-title">Processor</div>
          </div>
          <button className="text-sm text-primary hover:underline" onClick={() => setShowHistorical(!showHistorical)}>
            {showHistorical ? "Show Realtime" : "Show Historical"}
          </button>
        </div>
      </div>
      <div className="card-content">
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <div className="text-sm text-muted-foreground">Brand</div>
            <div className="font-medium">{cpuData?.model_name?.split(" ")[0] || "Intel"}</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">Model</div>
            <div className="font-medium">
              {cpuData?.model_name?.includes("AMD") ? cpuData?.model_name?.replace("AMD ", "") : "Core™ i7-10750H"}
            </div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">Cores</div>
            <div className="font-medium">{cpuData?.cores || 6}</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">Threads</div>
            <div className="font-medium">{cpuData?.threads || 12}</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">Frequency</div>
            <div className="font-medium">2.6 GHz</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">Temperature</div>
            <div className="font-medium">{cpuData?.temp ? `${cpuData.temp}°C` : "N/A"}</div>
          </div>
        </div>

        {showHistorical && (
          <div className="mb-4">
            <TimeRangeSelector selectedRange={selectedRange} onRangeChange={setSelectedRange} />
          </div>
        )}

        <div className="graph-container">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={showHistorical ? historicalData : realtimeData}
              margin={{ top: 5, right: 5, left: 0, bottom: 5 }}
            >
              <XAxis dataKey="time" type="number" domain={["dataMin", "dataMax"]} tickFormatter={formatTime} hide />
              <YAxis domain={[0, 100]} hide />
              <Tooltip content={<CustomTooltip />} />
              <Line
                type="monotone"
                dataKey="usage"
                stroke="hsl(var(--cpu-color))"
                strokeWidth={2}
                dot={false}
                isAnimationActive={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="mt-2 flex justify-between items-center">
          <div className="stat-value">{cpuData?.usage?.usage_percentage?.toFixed(2) || "0.00"}%</div>
          <div className="stat-label">Current Usage</div>
        </div>
      </div>
    </div>
  )
}

export default CpuCard

