"use client"

import { useState, useEffect } from "react"
import { useWebSocket } from "../../contexts/WebSocketContext"
import { LineChart, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"
import TimeRangeSelector from "../TimeRangeSelector"
import { format, subSeconds } from "date-fns"

const NetworkCard = ({ splitView }) => {
  const { networkData, fetchHistoricalData } = useWebSocket()
  const [historicalData, setHistoricalData] = useState([])
  const [realtimeData, setRealtimeData] = useState([])
  const [selectedRange, setSelectedRange] = useState(3600) // 1 hour by default
  const [showHistorical, setShowHistorical] = useState(false)

  // Format bytes to human-readable format
  const formatBytes = (bytes, decimals = 2) => {
    if (!bytes) return "0 B"

    const k = 1024
    const dm = decimals < 0 ? 0 : decimals
    const sizes = ["B", "KB", "MB", "GB", "TB"]

    const i = Math.floor(Math.log(bytes) / Math.log(k))

    return `${Number.parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`
  }

  // Update realtime data when new network data arrives
  useEffect(() => {
    if (networkData && networkData.length > 0) {
      setRealtimeData((prevData) => {
        const newData = [
          ...prevData,
          {
            time: new Date().getTime(),
            rx: networkData[0].usage.rx_bytes_ps,
            tx: networkData[0].usage.tx_bytes_ps,
          },
        ]

        // Keep only the last 60 data points (1 minute at 1 data point per second)
        if (newData.length > 60) {
          return newData.slice(-60)
        }
        return newData
      })
    }
  }, [networkData])

  // Fetch historical data when range changes
  useEffect(() => {
    if (showHistorical) {
      const fetchData = async () => {
        const endTime = new Date().toISOString()
        const startTime = subSeconds(new Date(), selectedRange).toISOString()
        const interval = Math.max(Math.floor(selectedRange / 60), 1) // At least 1 second interval

        const data = await fetchHistoricalData("network", startTime, endTime, interval)
        if (data && data.interfaces && data.interfaces.length > 0) {
          setHistoricalData(
            data.interfaces[0].data.map((item) => ({
              time: new Date(item.timestamp).getTime(),
              rx: item.rx_bytes_ps,
              tx: item.tx_bytes_ps,
            })),
          )
        }
      }

      fetchData()
    }
  }, [selectedRange, showHistorical, fetchHistoricalData])

  // Format time for tooltip
  const formatTime = (time) => {
    return format(new Date(time), "HH:mm:ss")
  }

  // Custom tooltip
  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card p-2 border border-border rounded shadow-sm">
          <p className="text-sm">{`Time: ${formatTime(payload[0].payload.time)}`}</p>
          <p className="text-sm text-[hsl(var(--network-color))]">{`Download: ${formatBytes(payload[0].value)}/s`}</p>
          {payload.length > 1 && (
            <p className="text-sm text-[hsl(var(--network-color))]">{`Upload: ${formatBytes(payload[1].value)}/s`}</p>
          )}
        </div>
      )
    }
    return null
  }

  return (
    <div className="card">
      <div className="card-header">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-[hsl(var(--network-color))] flex items-center justify-center mr-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 text-white"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"></path>
                <path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"></path>
                <path d="M4 22h16"></path>
                <path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"></path>
                <path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"></path>
                <path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"></path>
              </svg>
            </div>
            <div className="card-title">Network</div>
          </div>
          <button className="text-sm text-primary hover:underline" onClick={() => setShowHistorical(!showHistorical)}>
            {showHistorical ? "Show Realtime" : "Show Historical"}
          </button>
        </div>
      </div>
      <div className="card-content">
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <div className="text-sm text-muted-foreground">Type</div>
            <div className="font-medium">Wired</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">Interface</div>
            <div className="font-medium">{networkData?.[0]?.interface || "enp6s0"}</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">IP Address</div>
            <div className="font-medium">{networkData?.[0]?.ip || "192.168.9.2"}</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">Speed</div>
            <div className="font-medium">1.0 Gb/s</div>
          </div>
        </div>

        {showHistorical && (
          <div className="mb-4">
            <TimeRangeSelector selectedRange={selectedRange} onRangeChange={setSelectedRange} />
          </div>
        )}

        {splitView ? (
          <div className="grid grid-cols-2 gap-4">
            <div className="graph-container">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={showHistorical ? historicalData : realtimeData}
                  margin={{ top: 5, right: 5, left: 0, bottom: 5 }}
                >
                  <XAxis dataKey="time" type="number" domain={["dataMin", "dataMax"]} tickFormatter={formatTime} hide />
                  <YAxis hide />
                  <Tooltip content={<CustomTooltip />} />
                  <Line
                    type="monotone"
                    dataKey="rx"
                    stroke="hsl(var(--network-color))"
                    strokeWidth={2}
                    dot={false}
                    isAnimationActive={false}
                  />
                </LineChart>
              </ResponsiveContainer>
              <div className="mt-2 text-center">
                <div className="text-xs text-muted-foreground">Download</div>
              </div>
            </div>
            <div className="graph-container">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={showHistorical ? historicalData : realtimeData}
                  margin={{ top: 5, right: 5, left: 0, bottom: 5 }}
                >
                  <XAxis dataKey="time" type="number" domain={["dataMin", "dataMax"]} tickFormatter={formatTime} hide />
                  <YAxis hide />
                  <Tooltip content={<CustomTooltip />} />
                  <Line
                    type="monotone"
                    dataKey="tx"
                    stroke="hsl(var(--network-color))"
                    strokeWidth={2}
                    dot={false}
                    isAnimationActive={false}
                  />
                </LineChart>
              </ResponsiveContainer>
              <div className="mt-2 text-center">
                <div className="text-xs text-muted-foreground">Upload</div>
              </div>
            </div>
          </div>
        ) : (
          <div className="graph-container">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={showHistorical ? historicalData : realtimeData}
                margin={{ top: 5, right: 5, left: 0, bottom: 5 }}
              >
                <XAxis dataKey="time" type="number" domain={["dataMin", "dataMax"]} tickFormatter={formatTime} hide />
                <YAxis hide />
                <Tooltip content={<CustomTooltip />} />
                <Line
                  type="monotone"
                  dataKey="rx"
                  stroke="hsl(var(--network-color))"
                  strokeWidth={2}
                  dot={false}
                  isAnimationActive={false}
                />
                <Line
                  type="monotone"
                  dataKey="tx"
                  stroke="hsl(var(--network-color))"
                  strokeWidth={1}
                  strokeDasharray="3 3"
                  dot={false}
                  isAnimationActive={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}

        <div className="mt-2 grid grid-cols-2 gap-4">
          <div>
            <div className="text-sm text-muted-foreground">Download</div>
            <div className="font-medium">{formatBytes(networkData?.[0]?.usage?.rx_bytes_ps || 0)}/s</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">Upload</div>
            <div className="font-medium">{formatBytes(networkData?.[0]?.usage?.tx_bytes_ps || 0)}/s</div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default NetworkCard

