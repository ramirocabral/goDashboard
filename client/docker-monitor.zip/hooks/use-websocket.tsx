"use client"

import { useState, useEffect, useRef } from "react"

export function useWebSocket(url) {
  const [data, setData] = useState(null)
  const [connected, setConnected] = useState(false)
  const wsRef = useRef(null)

  useEffect(() => {
    // Create WebSocket connection
    const socket = new WebSocket(url)
    wsRef.current = socket

    // Connection opened
    socket.addEventListener("open", () => {
      console.log("WebSocket connection established")
      setConnected(true)
    })

    // Listen for messages
    socket.addEventListener("message", (event) => {
      try {
        const parsedData = JSON.parse(event.data)
        setData(parsedData)
      } catch (error) {
        console.error("Error parsing WebSocket data:", error)
      }
    })

    // Connection closed
    socket.addEventListener("close", () => {
      console.log("WebSocket connection closed")
      setConnected(false)

      // Try to reconnect after 5 seconds
      setTimeout(() => {
        if (wsRef.current?.readyState === WebSocket.CLOSED) {
          console.log("Attempting to reconnect...")
          // The useEffect cleanup will run on component unmount
          // so we don't need to worry about creating multiple connections
        }
      }, 5000)
    })

    // Connection error
    socket.addEventListener("error", (error) => {
      console.error("WebSocket error:", error)
      setConnected(false)
    })

    // Clean up on unmount
    return () => {
      if (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING) {
        socket.close()
      }
    }
  }, [url])

  return { data, connected }
}

